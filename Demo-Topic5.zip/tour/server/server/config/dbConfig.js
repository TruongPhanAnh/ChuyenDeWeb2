module.exports = {
  HOST: "localhost",
  PORT: 82,
  USER: "root",
  PASSWORD: "",
  DB: "sql12358708",
};
