module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "",
  DB: "sql12358708",
};
