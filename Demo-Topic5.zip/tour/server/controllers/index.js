const tourController = require('./tours')

module.exports = {
  tourController
}