export const tourData = [
  {
    id: 1,
    ten: "Tour Vũng Tàu",
    img: "./img/1.jpg",
    gia: "1.000.000 VND",
    info:
      "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Tenetur, nam omnis error corrupti eum assumenda enim odit architecto corporis. Sequi",
  },
  {
    id: 2,
    ten: "Tour Vũng Tàu",
    img: "./img/1.jpg",
    gia: "1.000.000 VND",
    info:
      "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Tenetur, nam omnis error corrupti eum assumenda enim odit architecto corporis. Sequi",
  },
  {
    id: 3,
    ten: "Tour Vũng Tàu",
    img: "./img/1.jpg",
    gia: "1.000.000 VND",
    info:
      "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Tenetur, nam omnis error corrupti eum assumenda enim odit architecto corporis. Sequi",
  },
  {
    id: 4,
    ten: "Tour Vũng Tàu",
    img: "./img/1.jpg",
    gia: "1.000.000 VND",
    info:
      "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Tenetur, nam omnis error corrupti eum assumenda enim odit architecto corporis. Sequi",
  },
];
